from modulos.interfaz import mostrar_menu_principal

if __name__ == "__main__":
    mostrar_menu_principal()